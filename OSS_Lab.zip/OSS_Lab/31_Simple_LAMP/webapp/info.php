<?php
// Simple PHP info page
phpinfo();
?>
