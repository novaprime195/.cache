# Django project init
