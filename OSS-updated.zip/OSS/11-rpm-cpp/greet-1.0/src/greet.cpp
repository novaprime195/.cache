#include <iostream>
#include "greet.h"

void greet() {
    std::cout << "Hello, welcome to the RPM C++ project!" << std::endl;
}

int main() {
    greet();
    return 0;
}
